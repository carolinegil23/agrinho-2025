// Variáveis Globais
let faseDoJogo = 'fazenda'; // pode ser 'fazenda', 'transporte', 'cidade'
let dinheiro = 100;
let inventario = {
  cenoura: 0,
  tomate: 4,
  trigo: 0
};
let sementes = {
  cenoura: 8,
  tomate: 8,
  trigo: 5
};

let fazendaTerrenos = []; // Array para armazenar os terrenos da fazenda
const TAMANHO_TERRENO = 60;
const LINHAS_FAZENDA = 5;
const COLUNAS_FAZENDA = 5;

let caminhao; // Objeto para o caminhão de transporte

// --- Pré-carregamento de Imagens (se você for usar) ---
let imgCenouraSemente, imgCenouraBroto, imgCenouraMadura;
let imgCaminhao;
let imgTerrenoArado, imgTerrenoPlantado;
// function preload() {
//   imgCenouraSemente = loadImage('assets/cenoura_semente.png');
//   imgCenouraBroto = loadImage('assets/cenoura_broto.png');
//   imgCenouraMadura = loadImage('assets/cenoura_madura.png');
//   imgCaminhao = loadImage('assets/caminhao.png');
//   imgTerrenoArado = loadImage('assets/terreno_arado.png');
//   imgTerrenoPlantado = loadImage('assets/terreno_plantado.png');
// }


function setup() {
  createCanvas(800, 600);
  // Inicializa os terrenos da fazenda
  for (let i = 0; i < LINHAS_FAZENDA; i++) {
    fazendaTerrenos[i] = [];
    for (let j = 0; j < COLUNAS_FAZENDA; j++) {
      fazendaTerrenos[i][j] = {
        x: 50 + j * (TAMANHO_TERRENO + 5),
        y: 100 + i * (TAMANHO_TERRENO + 5),
        plantado: false,
        tipoPlanta: null,
        estagioCrescimento: 0, // 0: nada, 1: semente, 2: broto, 3: jovem, 4: madura
        tempoPlantio: 0
      };
    }
  }

  // Inicializa o caminhão
  caminhao = {
    x: width / 2,
    y: height - 50,
    largura: 80,
    altura: 60,
    velocidade: 3,
    carga: {
      cenoura: 0,
      tomate: 0,
      trigo: 0
    }
  };
}

function draw() {
  background(135, 206, 235); // Céu azul

  // Desenha o cenário com base na fase do jogo
  if (faseDoJogo === 'fazenda') {
    desenharFazenda();
  } else if (faseDoJogo === 'transporte') {
    desenharEstrada();
    desenharCaminhao();
  } else if (faseDoJogo === 'cidade') {
    desenharCidade();
  }

  // Desenha a UI (dinheiro, inventário, botões)
  desenharUI();
}

// --- Funções de Desenho ---

function desenharFazenda() {
  // Desenha o fundo da fazenda (grama)
  fill(124, 252, 0); // Verde grama
  rect(0, 0, width, height);

  // Desenha os terrenos cultiváveis
  for (let i = 0; i < LINHAS_FAZENDA; i++) {
    for (let j = 0; j < COLUNAS_FAZENDA; j++) {
      let terreno = fazendaTerrenos[i][j];
      stroke(0);
      if (terreno.plantado) {
        fill(100, 70, 0); // Marrom escuro para terreno plantado
      } else {
        fill(139, 69, 19); // Marrom para terreno arado
      }
      rect(terreno.x, terreno.y, TAMANHO_TERRENO, TAMANHO_TERRENO);

      // Desenha a planta se houver
      if (terreno.plantado) {
        desenharPlanta(terreno);
        // Atualiza o crescimento da planta
        if (millis() - terreno.tempoPlantio > 5000 && terreno.estagioCrescimento < 4) { // Cresce a cada 5 segundos
          terreno.estagioCrescimento++;
          terreno.tempoPlantio = millis(); // Reinicia o contador para o próximo estágio
        }
      }
    }
  }

  // Adicione um botão para ir para a fase de transporte
  fill(0, 150, 0);
  rect(width - 150, height - 70, 120, 40);
  fill(255);
  textSize(16);
  textAlign(CENTER, CENTER);
  text("Transportar", width - 90, height - 50);
}

function desenharPlanta(terreno) {
  // Desenha a planta com base no estágio de crescimento
  // Você pode usar imagens ou formas simples aqui
  push();
  translate(terreno.x + TAMANHO_TERRENO / 2, terreno.y + TAMANHO_TERRENO / 2);
  if (terreno.tipoPlanta === 'cenoura') {
    if (terreno.estagioCrescimento === 1) { // Semente
      fill(100);
      ellipse(0, 0, 5, 5);
    } else if (terreno.estagioCrescimento === 2) { // Broto
      fill(0, 200, 0);
      rect(-2, 0, 4, -10);
    } else if (terreno.estagioCrescimento === 3) { // Jovem
      fill(0, 150, 0);
      rect(-5, 0, 10, -20);
    } else if (terreno.estagioCrescimento === 4) { // Madura (cenoura)
      fill(255, 100, 0); // Laranja
      triangle(0, 10, -10, -10, 10, -10); // Forma de cenoura simples
      fill(0, 150, 0);
      rect(-2, -10, 4, -10); // Folhas
    }
  }
  // Adicione lógica para outras plantas (tomate, trigo, etc.)
  pop();
}

function desenharEstrada() {
  background(100); // Cinza para a estrada
  fill(50);
  rect(width / 4, 0, width / 2, height); // Estrada principal
  // Linhas da estrada
  for (let i = 0; i < height; i += 40) {
    fill(255, 255, 0);
    rect(width / 2 - 5, i, 10, 20);
  }
}

function desenharCaminhao() {
  fill(200, 0, 0); // Caminhão vermelho
  rect(caminhao.x - caminhao.largura / 2, caminhao.y - caminhao.altura / 2, caminhao.largura, caminhao.altura);
  // Rodas
  fill(0);
  ellipse(caminhao.x - caminhao.largura / 3, caminhao.y + caminhao.altura / 2, 15, 15);
  ellipse(caminhao.x + caminhao.largura / 3, caminhao.y + caminhao.altura / 2, 15, 15);

  // Movimento do caminhão (exemplo simples: move para cima)
  if (faseDoJogo === 'transporte') {
    caminhao.y -= caminhao.velocidade;
    if (caminhao.y < -caminhao.altura) {
      faseDoJogo = 'cidade';
      caminhao.y = height - 50; // Reinicia posição para a próxima viagem
    }
  }
}

function desenharCidade() {
  background(150, 150, 150); // Cinza claro para o fundo da cidade
  // Desenha alguns edifícios simples
  fill(100, 100, 100);
  rect(50, height - 150, 80, 120);
  rect(150, height - 200, 100, 170);
  rect(300, height - 100, 60, 70);

  // Desenha os comércios
  fill(255, 200, 0); // Amarelo para comércios
  rect(width / 2 - 75, height / 2 - 50, 150, 100);
  fill(0);
  textSize(18);
  text("Mercado Central", width / 2, height / 2);

  // Botão para vender alimentos
  fill(0, 100, 0);
  rect(width / 2 - 60, height / 2 + 70, 120, 40);
  fill(255);
  textSize(16);
  text("Vender Alimentos", width / 2, height / 2 + 90);

  // Botão para retornar à fazenda
  fill(0, 0, 150);
  rect(width - 150, height - 70, 120, 40);
  fill(255);
  textSize(16);
  textAlign(CENTER, CENTER);
  text("Voltar Fazenda", width - 90, height - 50);
}

function desenharUI() {
  fill(0);
  textSize(20);
  textAlign(LEFT, TOP);
  text(`Dinheiro: $${dinheiro}`, 10, 10);
  text(`Cenoura: ${inventario.cenoura}`, 10, 40);
  text(`Tomate: ${inventario.tomate}`, 10, 70);
  text(`Trigo: ${inventario.trigo}`, 10, 100);

  // Inventário de Sementes (apenas na fase da fazenda)
  if (faseDoJogo === 'fazenda') {
    text(`Sementes Cenoura: ${sementes.cenoura}`, width - 200, 10);
    text(`Sementes Tomate: ${sementes.tomate}`, width - 200, 40);
    text(`Sementes Trigo: ${sementes.trigo}`, width - 200, 70);
  }

  // Carga do caminhão (apenas na fase de transporte ou cidade)
  if (faseDoJogo === 'transporte' || faseDoJogo === 'cidade') {
    text(`Carga Cenoura: ${caminhao.carga.cenoura}`, 10, 130);
    text(`Carga Tomate: ${caminhao.carga.tomate}`, 10, 160);
    text(`Carga Trigo: ${caminhao.carga.trigo}`, 10, 190);
  }
}

// --- Funções de Interação (Mouse) ---

function mousePressed() {
  if (faseDoJogo === 'fazenda') {
    // Lógica para plantar e colher
    for (let i = 0; i < LINHAS_FAZENDA; i++) {
      for (let j = 0; j < COLUNAS_FAZENDA; j++) {
        let terreno = fazendaTerrenos[i][j];
        if (mouseX > terreno.x && mouseX < terreno.x + TAMANHO_TERRENO &&
          mouseY > terreno.y && mouseY < terreno.y + TAMANHO_TERRENO) {

          if (!terreno.plantado && sementes.cenoura > 0) { // Exemplo: plantar cenoura
            terreno.plantado = true;
            terreno.tipoPlanta = 'cenoura';
            terreno.estagioCrescimento = 1;
            terreno.tempoPlantio = millis();
            sementes.cenoura--;
            console.log("Plantei cenoura!");
            break; // Sai do loop para evitar plantar em múltiplos terrenos com um clique
          } else if (terreno.plantado && terreno.estagioCrescimento === 4) { // Colher
            inventario[terreno.tipoPlanta]++;
            terreno.plantado = false;
            terreno.tipoPlanta = null;
            terreno.estagioCrescimento = 0;
            terreno.tempoPlantio = 0;
            console.log(`Colhi ${terreno.tipoPlanta}!`);
            break;
          }
        }
      }
    }

    // Botão Transportar
    if (mouseX > width - 150 && mouseX < width - 30 &&
      mouseY > height - 70 && mouseY < height - 30) {
      // Carrega o caminhão com todos os itens do inventário
      caminhao.carga.cenoura = inventario.cenoura;
      caminhao.carga.tomate = inventario.tomate; // Adicionar lógica para outros itens
      caminhao.carga.trigo = inventario.trigo; // Adicionar lógica para outros itens
      inventario.cenoura = 0; // Zera o inventário após carregar no caminhão
      inventario.tomate = 0;
      inventario.trigo = 0;

      faseDoJogo = 'transporte';
      console.log("Indo para a cidade!");
    }

  } else if (faseDoJogo === 'cidade') {
    // Botão Vender Alimentos
    if (mouseX > width / 2 - 60 && mouseX < width / 2 + 60 &&
      mouseY > height / 2 + 70 && mouseY < height / 2 + 110) {
      dinheiro += caminhao.carga.cenoura * 5; // Preço exemplo: 5 por cenoura
      dinheiro += caminhao.carga.tomate * 7; // Preço exemplo: 7 por tomate
      dinheiro += caminhao.carga.trigo * 3; // Preço exemplo: 3 por trigo
      caminhao.carga.cenoura = 0; // Zera a carga do caminhão
      caminhao.carga.tomate = 0;
      caminhao.carga.trigo = 0;
      console.log("Alimentos vendidos!");
    }

    // Botão Voltar Fazenda
    if (mouseX > width - 150 && mouseX < width - 30 &&
      mouseY > height - 70 && mouseY < height - 30) {
      faseDoJogo = 'fazenda';
      console.log("Voltando para a fazenda!");
    }
  }
}

// --- Funções de Teclado (para o caminhão, se quiser) ---
function keyPressed() {
  if (faseDoJogo === 'transporte') {
    if (keyCode === LEFT_ARROW) {
      caminhao.x -= caminhao.velocidade * 2;
    } else if (keyCode === RIGHT_ARROW) {
      caminhao.x += caminhao.velocidade * 2;
    }
    // Limita o caminhão na estrada
    caminhao.x = constrain(caminhao.x, width / 4 + caminhao.largura / 2, width * 3 / 4 - caminhao.largura / 2);
  }
}